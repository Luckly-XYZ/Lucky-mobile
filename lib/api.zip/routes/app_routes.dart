import 'package:flutter_im/pages/auth/login_page.dart';
import 'package:flutter_im/pages/home/home_page.dart';
import 'package:flutter_im/pages/message/message_page.dart';
import 'package:flutter_im/pages/profile/profile_qr_code_page.dart';
import 'package:flutter_im/pages/scan/scan_page.dart';
import 'package:flutter_im/pages/settings/settings_page.dart';
import 'package:get/get.dart';


class AppRoutes {
  // 登录
  static const String LOGIN = '/login';

  // 首页
  static const String HOME = '/home';

  // 扫码
  static const String SCAN = '/scan';

  // 我的二维码
  static const String PROFILE_QR_CODE = '/profile/qr_code';

  // 网页浏览
  //static const String WEB_VIEW = '/web_view';

  // 设置
  static const String SETTINGS = '/settings';

  // 搜索
  static const String SEARCH = '/search';

  // 聊天
  static const String MESSAGE = '/message';


  static final routes = [
    GetPage(

      name: LOGIN,
      page: () => LoginPage(),
    ),
    GetPage(
      name: HOME,
      page: () => HomePage(),
    ),
    GetPage(
      name: SCAN,
      page: () => ScanPage(),
    ),
    GetPage(
      name: PROFILE_QR_CODE,
      page: () => ProfileQRCodePage(),
    ),
    GetPage(
      name: SETTINGS,
      page: () => SettingsPage(),
    ),
    GetPage(
      name: MESSAGE,
      page: () => MessagePage(),
    ),
  ];
}

