import 'auth_api.dart';
import 'chat_api.dart';
import 'file_api.dart';
import 'message_api.dart';
import 'user_api.dart';

/// **API 统一管理类**
class API {
  /// 消息相关接口
  static final MessageApi message = MessageApi();

  /// 会话相关接口
  static final ChatApi chat = ChatApi();

  /// 用户相关接口
  static final UserApi user = UserApi();

  /// 认证相关接口
  static final AuthApi auth = AuthApi();

  /// 文件上传接口
  static final FileApi file = FileApi();
}
