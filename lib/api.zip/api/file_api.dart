import 'package:dio/dio.dart';

import '../utils/http.dart';

/// **📂 文件 API**
class FileApi {
  /// **文件上传**
  Future<Map<String, dynamic>?> uploadFile(FormData data) {
    return HttpService.post('/service/file/formUpload', data: data);
  }
}
