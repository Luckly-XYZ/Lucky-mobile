import '../utils/http.dart';

/// **🔐 认证 API**
class AuthApi {
  /// **用户登录**
  Future<Map<String, dynamic>?> login(Map<String, dynamic> data) {
    return HttpService.post('/auth/user/login', data: data);
  }

  /// **用户退出登录**
  Future<Map<String, dynamic>?> logout(Map<String, dynamic> data) {
    return HttpService.post('/auth/user/logout', data: data);
  }

  /// **获取短信验证码**
  Future<Map<String, dynamic>?> sendSms(Map<String, dynamic> data) {
    return HttpService.get('/auth/user/sms', params: data);
  }

  /// **获取二维码**
  Future<Map<String, dynamic>?> getQRCode(Map<String, dynamic> data) {
    return HttpService.get('/auth/user/qrcode', params: data);
  }

  /// **扫码登录**
  Future<Map<String, dynamic>?> scanQRCode(Map<String, dynamic> data) {
    return HttpService.post('/auth/user/qrcode/scan', data: data);
  }

  /// **检查二维码状态**
  Future<Map<String, dynamic>?> checkQRCodeStatus(Map<String, dynamic> data) {
    return HttpService.get('/auth/user/qrcode/status', params: data);
  }

  /// **获取公钥**
  Future<Map<String, dynamic>?> getPublicKey() {
    return HttpService.get('/auth/user/publickey');
  }

  /// **获取在线状态**
  Future<Map<String, dynamic>?> getOnlineStatus(Map<String, dynamic> data) {
    return HttpService.get('/auth/user/online', params: data);
  }

  /// **刷新 Token**
  Future<Map<String, dynamic>?> refreshToken(Map<String, dynamic> data) {
    return HttpService.post('/auth/user/refreshToken', data: data);
  }
}
