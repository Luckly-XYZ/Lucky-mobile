import '../utils/http.dart';

/// **📩 消息 API**
class MessageApi {
  /// **发送单聊消息**
  Future<Map<String, dynamic>?> sendSingleMessage(Map<String, dynamic> data) {
    return HttpService.post('/service/message/single/send', data: data);
  }

  /// **发送群聊消息**
  Future<Map<String, dynamic>?> sendGroupMessage(Map<String, dynamic> data) {
    return HttpService.post('/service/message/group/send', data: data);
  }

  /// **获取群成员**
  Future<Map<String, dynamic>?> getGroupMember(Map<String, dynamic> data) {
    return HttpService.post('/service/message/group/member', data: data);
  }

  /// **退出群聊**
  Future<Map<String, dynamic>?> quitGroup(Map<String, dynamic> data) {
    return HttpService.post('/service/message/group/quit', data: data);
  }

  /// **邀请群成员**
  Future<Map<String, dynamic>?> inviteGroupMember(Map<String, dynamic> data) {
    return HttpService.post('/service/message/group/invite', data: data);
  }

  /// **获取消息列表**
  Future<Map<String, dynamic>?> getMessageList(Map<String, dynamic> data) {
    return HttpService.post('/service/message/list', data: data);
  }

  /// **检查单聊消息**
  Future<Map<String, dynamic>?> checkSingleMessage(Map<String, dynamic> data) {
    return HttpService.post('/service/message/singleCheck', data: data);
  }

  /// **发送视频消息**
  Future<Map<String, dynamic>?> sendCallMessage(Map<String, dynamic> data) {
    return HttpService.post('/service/video/send', data: data);
  }
}
