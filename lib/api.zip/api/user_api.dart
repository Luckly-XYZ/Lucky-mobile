import '../utils/http.dart';

/// **👤 用户 API**
class UserApi {
  /// **获取个人信息**
  Future<Map<String, dynamic>?> getUserInfo(Map<String, dynamic> data) {
    return HttpService.get('/auth/user/info', params: data);
  }

  /// **获取好友列表**
  Future<Map<String, dynamic>?> getFriendList(Map<String, dynamic> data) {
    return HttpService.get('/service/friend/list', params: data);
  }
}
