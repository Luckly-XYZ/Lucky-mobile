import '../utils/http.dart';

/// **💬 会话 API**
class ChatApi {
  /// **获取会话列表**
  Future<Map<String, dynamic>?> getChatList(Map<String, dynamic> data) {
    return HttpService.post('/service/chat/list', data: data);
  }

  /// **获取单个会话**
  Future<Map<String, dynamic>?> getChat(Map<String, dynamic> data) {
    return HttpService.get('/service/chat/one', params: data);
  }

  /// **标记会话已读**
  Future<Map<String, dynamic>?> readChat(Map<String, dynamic> data) {
    return HttpService.post('/service/chat/read', data: data);
  }

  /// **创建会话**
  Future<Map<String, dynamic>?> createChat(Map<String, dynamic> data) {
    return HttpService.post('/service/chat/create', data: data);
  }
}
