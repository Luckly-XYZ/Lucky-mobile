import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter_im/stores/impl/user_store.dart';

import '../config/app_config.dart';

/// 网络请求工具类，基于 Dio 进行封装
///
/// 支持：
/// - `GET`、`POST`、`PUT`、`DELETE` 请求
/// - 全局错误处理
/// - 请求超时设置
/// - 请求/响应拦截器
class HttpService {
  /// Dio 实例
  static final Dio _dio = Dio(BaseOptions(
    baseUrl: AppConfig.apiServer, // 🔹 请修改为你的 API 地址
    connectTimeout: const Duration(seconds: 10), // 连接超时时间
    receiveTimeout: const Duration(seconds: 10), // 读取超时时间
    sendTimeout: const Duration(seconds: 10), // 发送超时时间
    //headers: {"Content-Type": "application/json"},
  ))
    ..interceptors.add(LogInterceptor(
      request: true,
      requestHeader: true,
      requestBody: true,
      responseHeader: false,
      responseBody: true,
      error: true,
    ));

  ///
  /// 添加拦截器，动态更新 `Authorization` 头
  ///
  static void init() {
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (RequestOptions options, RequestInterceptorHandler handler) {
        // 1️⃣ 动态获取最新的 Token
        String token = UserStore().token;
        if (token.isNotEmpty) {
          options.headers["Authorization"] = "Bearer $token";
        }
        options.headers["Content-Type"] = "application/json";

        print("🚀 发送请求: ${options.method} ${options.uri}");
        print("🔹 请求头: ${options.headers}");
        handler.next(options);
      },
      onResponse: (Response response, ResponseInterceptorHandler handler) {
        print("✅ 响应成功: ${response.data}");
        handler.next(response);
      },
      onError: (DioException e, ErrorInterceptorHandler handler) {
        print("❌ 请求错误: ${e.message}");
        handler.next(e);
      },
    ));
  }

  /// 发送 `GET` 请求
  ///
  /// - [path] 请求路径，自动拼接 `baseUrl`
  /// - [params] URL 查询参数（可选）
  /// - [options] 自定义请求配置（可选）
  /// - 返回 JSON 格式的 `Map<String, dynamic>`
  static Future<Map<String, dynamic>?> get(String path,
      {Map<String, dynamic>? params, Options? options}) async {
    try {
      Response response =
          await _dio.get(path, queryParameters: params, options: options);
      return _handleResponse(response);
    } catch (e) {
      _handleError(e);
      return null;
    }
  }

  /// 发送 `POST` 请求
  ///
  /// - [path] 请求路径
  /// - [data] 请求体，可以是 `Map`、`List` 或者 `FormData`
  /// - [params] URL 查询参数（可选）
  /// - [options] 自定义请求配置（可选）
  /// - 返回 JSON 格式的 `Map<String, dynamic>`
  static Future<Map<String, dynamic>?> post(String path,
      {dynamic data, Map<String, dynamic>? params, Options? options}) async {
    try {
      Response response = await _dio.post(path,
          data: data, queryParameters: params, options: options);
      return _handleResponse(response);
    } catch (e) {
      _handleError(e);
      return null;
    }
  }

  /// 发送 `PUT` 请求
  ///
  /// - [path] 请求路径
  /// - [data] 请求体
  /// - [params] URL 查询参数（可选）
  /// - [options] 自定义请求配置（可选）
  /// - 返回 JSON 格式的 `Map<String, dynamic>`
  static Future<Map<String, dynamic>?> put(String path,
      {dynamic data, Map<String, dynamic>? params, Options? options}) async {
    try {
      Response response = await _dio.put(path,
          data: data, queryParameters: params, options: options);
      return _handleResponse(response);
    } catch (e) {
      _handleError(e);
      return null;
    }
  }

  /// 发送 `DELETE` 请求
  ///
  /// - [path] 请求路径
  /// - [params] URL 查询参数（可选）
  /// - [options] 自定义请求配置（可选）
  /// - 返回 JSON 格式的 `Map<String, dynamic>`
  static Future<Map<String, dynamic>?> delete(String path,
      {Map<String, dynamic>? params, Options? options}) async {
    try {
      Response response =
          await _dio.delete(path, queryParameters: params, options: options);
      return _handleResponse(response);
    } catch (e) {
      _handleError(e);
      return null;
    }
  }

  /// 处理 HTTP 响应
  ///
  /// - [response] Dio 的 Response 对象
  /// - 返回解析后的 JSON 数据（`Map<String, dynamic>`）
  static Map<String, dynamic>? _handleResponse(Response response) {
    if (response.statusCode == 200 || response.statusCode == 201) {
      return response.data is String
          ? jsonDecode(response.data)
          : response.data;
    } else {
      throw DioException(
          requestOptions: response.requestOptions, response: response);
    }
  }

  /// 处理 Dio 异常
  ///
  /// - [error] 可能的异常类型：
  ///   - `DioException`：网络请求错误
  ///   - 其他异常：未知错误
  static void _handleError(dynamic error) {
    if (error is DioException) {
      switch (error.type) {
        case DioExceptionType.connectionTimeout:
          print("⏳ 连接超时");
          break;
        case DioExceptionType.receiveTimeout:
          print("⚠️  接收数据超时");
          break;
        case DioExceptionType.sendTimeout:
          print("🚀  发送数据超时");
          break;
        case DioExceptionType.badResponse:
          print("❌  服务器错误: ${error.response?.statusCode}");
          break;
        case DioExceptionType.cancel:
          print("❎  请求被取消");
          break;
        case DioExceptionType.unknown:
          print("🤷  未知错误: ${error.message}");
          break;
        default:
          print("🛑  其他错误: ${error.message}");
      }
    } else {
      print("❌  未知异常: $error");
    }
  }
}
