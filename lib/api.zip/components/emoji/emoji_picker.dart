import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EmojiPicker extends StatefulWidget {
  /// 当用户选中表情时的回调
  final ValueChanged<String> onEmojiSelected;

  const EmojiPicker({Key? key, required this.onEmojiSelected})
      : super(key: key);

  @override
  _EmojiPickerState createState() => _EmojiPickerState();
}

class _EmojiPickerState extends State<EmojiPicker>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // 从给定的 JSON 数据中解析得到的全部表情列表
  final List<String> _allEmojis =
      "😀,😁,😂,😃,😄,😅,😆,😉,😊,😋,😎,😍,😘,😗,😙,😚,😇,😐,😑,😶,😏,😣,😥,😮,😯,😪,😫,😴,😌,😛,😜,😝,😒,😓,😔,😕,😲,😷,😖,😞,😟,😤,😢,😭,😦,😧,😨,😬,😰,😱,😳,😵,😡,😠,💘,❤,💓,💔,💕,💖,💗,💙,💚,💛,💜,💝,💞,💟,❣,💪,👈,👉,☝,👆,👇,✌,✋,👌,👍,👎,✊,👊,👋,👏,👐,✍,🍇,🍈,🍉,🍊,🍋,🍌,🍍,🍎,🍏,🍐,🍑,🍒,🍓,🍅,🍆,🌽,🍄,🌰,🍞,🍖,🍗,🍔,🍟,🍕,🍳,🍲,🍱,🍘,🍙,🍚,🍛,🍜,🍝,🍠,🍢,🍣,🍤,🍥,🍡,🍦,🍧,🍨,🍩,🍪,🎂,🍰,🍫,🍬,🍭,🍮,🍯,🍼,☕,🍵,🍶,🍷,🍸,🍹,🍺,🍻,🍴,🌹,🍀,🍎,💰,📱,🌙,🍁,🍂,🍃,🌷,💎,🔪,🔫,🏀,⚽,⚡,👄,👍,🔥,🙈,🙉,🙊,🐵,🐒,🐶,🐕,🐩,🐺,🐱,😺,😸,😹,😻,😼,😽,🙀,😿,😾,🐈,🐯,🐅,🐆,🐴,🐎,🐮,🐂,🐃,🐄,🐷,🐖,🐗,🐽,🐏,🐑,🐐,🐪,🐫,🐘,🐭,🐁,🐀,🐹,🐰,🐇,🐻,🐨,🐼,🐾,🐔,🐓,🐣,🐤,🐥,🐦,🐧,🐸,🐊,🐢,🐍,🐲,🐉,🐳,🐋,🐬,🐟,🐠,🐡,🐙,🐚,🐌,🐛,🐜,🐝,🐞,🦋,😈,👿,👹,👺,💀,☠,👻,👽,👾,💣"
          .split(',')
          .map((e) => e.trim())
          .toList();

  // 最近使用的表情列表，最多存放 8 个
  List<String> _recentEmojis = [];
  final String _recentKey = "recent_emojis";

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadRecentEmojis();
  }

  /// 从 SharedPreferences 加载最近使用的表情
  Future<void> _loadRecentEmojis() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? storedEmojis = prefs.getStringList(_recentKey);
    if (storedEmojis != null) {
      setState(() {
        _recentEmojis = storedEmojis;
      });
    }
  }

  /// 保存最近使用的表情到 SharedPreferences
  Future<void> _saveRecentEmojis() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_recentKey, _recentEmojis);
  }

  /// 处理用户点击表情的逻辑
  void _onEmojiTap(String emoji) {
    setState(() {
      // 如果该表情已经存在，则移除后插入到首位
      _recentEmojis.remove(emoji);
      _recentEmojis.insert(0, emoji);
      // 保持最近列表最多 8 个
      if (_recentEmojis.length > 8) {
        _recentEmojis = _recentEmojis.sublist(0, 8);
      }
    });
    _saveRecentEmojis();
    widget.onEmojiSelected(emoji);
  }

  /// 构建单个表情的 Widget
  Widget _buildEmojiItem(String emoji) {
    return GestureDetector(
      onTap: () => _onEmojiTap(emoji),
      behavior: HitTestBehavior.opaque,
      child: Center(
        child: Text(
          emoji,
          style: const TextStyle(fontSize: 24),
        ),
      ),
    );
  }

  /// 构建表情网格
  Widget _buildEmojiGrid(List<String> emojis) {
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: emojis.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 8,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 1.0,
      ),
      itemBuilder: (context, index) {
        return _buildEmojiItem(emojis[index]);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 36, // 减小 TabBar 的高度
          child: TabBar(
            controller: _tabController,
            labelColor: Theme.of(context).primaryColor,
            unselectedLabelColor: Colors.grey,
            tabs: const [
              Tab(
                child: Text(
                  "😀", // 使用第一个表情作为标题
                  style: TextStyle(fontSize: 18),
                ),
              ),
              Tab(text: '其他'),
            ],
            indicatorWeight: 2, // 减小指示器的粗细
            labelPadding: EdgeInsets.zero, // 移除标签内边距
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              // 表情页面使用 ListView 实现整页滚动
              ListView(
                children: [
                  // 最近使用的表情区域
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "最近使用",
                      style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  ),
                  // 最近使用的表情网格
                  _recentEmojis.isEmpty
                      ? const SizedBox(
                          height: 80,
                          child: Center(child: Text("暂无最近使用的表情")),
                        )
                      : _buildEmojiGrid(_recentEmojis),
                  // 全部表情区域
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "全部表情",
                      style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  ),
                  // 全部表情网格
                  _buildEmojiGrid(_allEmojis),
                ],
              ),
              // 第二个 tab 的内容（预留）
              const Center(child: Text("更多功能开发中...")),
            ],
          ),
        ),
      ],
    );
  }
}
