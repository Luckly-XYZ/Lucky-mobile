import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import 'utils/http.dart';
import 'pages/home/home_page.dart';
//import 'database/app_database.dart';
import 'routes/app_routes.dart';
import 'stores/impl/chat_store.dart';
import 'stores/impl/message_store.dart';
import 'stores/impl/user_store.dart';
import 'utils/logger.dart';
import 'stores/impl/websocket_store.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  initGetX();
  Get.put(WebSocketStore());
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserStore()),
        ChangeNotifierProvider(create: (_) => MessageStore()),
        ChangeNotifierProvider(create: (_) => ChatStore()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter IM',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      initialRoute: AppRoutes.LOGIN,
      getPages: AppRoutes.routes,
      home: const HomePage(),
    );
  }
}

// 全局初始化
initGetX() async {
  HttpService.init(); // 确保 Dio 的拦截器生效
  //DatabaseProvider().init();
  Get.put(UserStore());
  Get.put(ChatStore());
  Get.put(AppLogger()); // 初始化日志
}
