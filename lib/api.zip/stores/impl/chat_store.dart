import 'dart:math';

import '../../database/model/chats.dart';
import '../persistent_store.dart';

class ChatStore extends PersistentStore {
  // 🔥 单例模式，确保整个应用只会创建一个 ChatStore 实例
  static final ChatStore _instance = ChatStore._internal();

  factory ChatStore() => _instance;

  ChatStore._internal()
      : super(
            storeName: 'chat_store',
            persistFields: ['chatList', 'currentChat']);

  List<Chats> get chatList => get('chatList') ?? []; // 会话列表
  Chats get currentChat => get('currentChat'); // 当前会话

  void setChatList(List<Chats> chatList) => set('chatList', chatList);

  void setCurrentChat(Chats currentChat) => set('currentChat', currentChat);

  Future<void> generateMockData({int count = 50}) async {
    final List<Chats> chatsList = [];
    final Random random = Random();
    final now = DateTime.now();

    for (int i = 0; i < count; i++) {
      // 模拟部分数据：
      // chat_id: 从1开始的自增值
      // chat_type: 0 或 1
      // owner_id: 模拟用户ID，如 "user_1"
      // to_id: 模拟目标用户ID，如 "user_2"
      // is_mute: 0 表示未开启免打扰，1 表示开启
      // is_top: 0 表示未置顶，1 表示置顶
      // sequence: 模拟顺序号
      // name: 聊天名称
      // avatar: 模拟头像URL
      // unread: 随机未读消息数（0~5之间）
      // id: 消息ID，如 "msg_1"
      // message: 聊天消息内容
      // message_time: 模拟消息时间，依次往前推 5 分钟
      Chats chat = Chats(
        i + 1,
        // chat_id
        i % 2,
        // chat_type
        'user_${i + 1}',
        // owner_id
        'user_${i + 2}',
        // to_id
        i % 2,
        // is_mute
        i % 2,
        // is_top
        i,
        // sequence
        'Chat ${i + 1}',
        // name
        'https://img0.baidu.com/it/u=1472806772,699408928&fm=253&fmt=auto&app=120&f=JPEG?w=500&h=500',
        // avatar
        random.nextInt(6),
        // unread (0-5)
        'msg_${i + 1}',
        // id
        'This is a sample message from chat ${i + 1}',
        // message
        now
            .subtract(Duration(minutes: i * 5))
            .millisecondsSinceEpoch, // message_time
      );
      chatsList.add(chat);
    }
    setChatList(chatsList);
    notifyListeners();
  }

// Future<void> _loadChats() async {
//   if (_chatsDao == null) return;
//   _chats = await _chatsDao!.findAllChats();
//   notifyListeners();
// }

// Future<void> addChat(Chats chat) async {
//   if (_chatsDao == null) return;
//   await _chatsDao!.insertChat(chat);
//   await _loadChats();
// }

// Future<void> updateChat(Chats chat) async {
//   if (_chatsDao == null) return;
//   await _chatsDao!.updateChat(chat);
//   await _loadChats();
// }

// Future<void> deleteChat(Chats chat) async {
//   if (_chatsDao == null) return;
//   await _chatsDao!.deleteChat(chat);
//   await _loadChats();
// }
}
