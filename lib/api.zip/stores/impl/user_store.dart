import 'package:flutter_im/api/api.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../utils/rsa.dart';
import '../persistent_store.dart';

/// 用户 Store（持久化 token 和用户名）
class UserStore extends PersistentStore {
  // 🔥 单例模式，确保整个应用只会创建一个 UserStore 实例
  static final UserStore _instance = UserStore._internal();

  factory UserStore() => _instance;

  UserStore._internal()
      : super(storeName: 'user_store', persistFields: ['token', 'userId']);

  String get token => get('token') ?? '';

  String get userId => get('userId') ?? '';

  Map<String, dynamic> get userInfo => get('userInfo') ?? {};
  String publicKey = '';

  // 设置 token
  void setToken(String token) => set('token', token);

  // 设置用户 ID
  void setUserId(String userId) => set('userId', userId);

  // 设置用户信息
  void setUserInfo(dynamic userInfo) => set('userInfo', userInfo);

  // 清除用户信息
  void clearUserInfo() {
    setToken('');
    setUserId('');
  }

  /// 登录
  ///
  /// [username] 用户名
  /// [password] 密码
  ///
  /// 返回是否登录成功
  Future<bool> login(String username, String password, String authType) async {
    try {
      // 1️⃣ 加密密码
      String encryptedPassword = await RSAService.encrypt(password, publicKey);
      print("🔑 加密后的密码: $encryptedPassword");

      // 2️⃣ 组装请求参数
      Map<String, dynamic> loginData = {
        "principal": username,
        "credentials": encryptedPassword,
        "authType": authType
      };
      print("📡 发送登录请求: $loginData");

      // 3️⃣ 发起登录请求
      var response = await API.auth.login(loginData);
      print("🔹 登录接口响应: $response");

      // 4️⃣ 处理登录结果
      if (response != null && response['data'] != null) {
        var data = response['data'];

        // 检查 token 和 userId 是否存在
        if (data['token'] != null && data['username'] != null) {
          setToken(data['token']);
          setUserId(data['username']);
          print("✅ 登录成功，Token: ${data['token']}");
          return true;
        } else {
          print("⚠️ 登录失败，服务器返回的数据不完整");
          return false;
        }
      } else {
        print("❌ 登录失败，服务器返回空数据");
        return false;
      }
    } catch (e, stackTrace) {
      print("🚨 登录发生异常: $e");
      print("📝 堆栈信息: $stackTrace");
      return false;
    }
  }

  ///
  /// 发送验证码
  ///
  Future<void> sendVerificationCode(String phone) async {
    await API.auth.sendSms({"phone": phone});
  }

  ///
  /// 获取公钥
  ///
  void getPublicKey() async {
    var response = await API.auth.getPublicKey();
    if (response != null) {
      print("✅ 获取公钥成功: ${response}");
      this.publicKey = response['publicKey'];
    } else {
      print("❌ 获取公钥失败");
    }
  }

  ///
  /// 获取用户信息
  ///
  Future<void> getUserInfo() async {
    try {
      final response = await API.user.getUserInfo({"user_id": userId});
      if (response != null) {
        print("✅ 获取用户信息成功: ${response}");
        setUserInfo(response);
        notifyListeners(); // 通知所有监听者（包括 profile_tab）数据已更新
      } else {
        print("❌ 获取用户信息失败");
      }
    } catch (e) {
      print('获取用户信息失败: $e');
      rethrow;
    }
  }

  ///
  /// 扫描二维码
  /// qrCodeContent: 二维码内容
  ///
  Future<bool> scanQrCode(String qrCodeContent) async {
    try {
      // 调用接口，传递二维码内容和当前用户 ID
      final response = await API.auth.scanQRCode({
        "qrcode": qrCodeContent,
        "userId": userId,
      });

      print("🔹 扫描二维码接口响应: $response");

      // 根据接口返回结果判断是否成功，
      // 这里假设接口返回数据包含 'success' 字段，若成功返回 true，否则返回 false
      if (response != null && response['status'] == 'success') {
        return true;
      }
      return false;
    } catch (error, stackTrace) {
      print("扫描二维码异常: $error");
      print("$stackTrace");
      return false;
    }
  }

  // 登出时清除用户信息
  Future<void> logout() async {
    //setUserInfo(null);
    setToken('');
    setUserId('');
    // ... 其他登出逻辑 ...
    notifyListeners();
  }

  // 保存凭证
  Future<void> saveCredentials(String username, String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_username', username);
    await prefs.setString('saved_password', password);
  }

  // 获取保存的凭证
  Future<Map<String, String>?> getSavedCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    final username = prefs.getString('saved_username');
    final password = prefs.getString('saved_password');

    if (username != null && password != null) {
      return {
        'username': username,
        'password': password,
      };
    }
    return null;
  }

  // 清除保存的凭证
  Future<void> clearSavedCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('saved_username');
    await prefs.remove('saved_password');
  }
}
