import 'package:flutter/foundation.dart';

import '../../database/dao/group_message_dao.dart';
import '../../database/dao/single_message_dao.dart';
import '../../database/model/group_message.dart';
import '../../database/model/single_message.dart';

class MessageStore extends ChangeNotifier {
  List<SingleMessage> _singleMessages = [];
  List<GroupMessage> _groupMessages = [];

  SingleMessageDao? _singleMessageDao;
  GroupMessageDao? _groupMessageDao;

  List<SingleMessage> get singleMessages => _singleMessages;

  List<GroupMessage> get groupMessages => _groupMessages;

// void setSingleMessageDao(SingleMessageDao dao) {
//   _singleMessageDao = dao;
//   _loadSingleMessages();
// }

// void setGroupMessageDao(GroupMessageDao dao) {
//   _groupMessageDao = dao;
//   _loadGroupMessages();
// }

// Future<void> _loadSingleMessages() async {
//   if (_singleMessageDao == null) return;
//   _singleMessages = await _singleMessageDao!.findAllSingleMessages();
//   notifyListeners();
// }

// Future<void> _loadGroupMessages() async {
//   if (_groupMessageDao == null) return;
//   _groupMessages = await _groupMessageDao!.findAllGroupMessages();
//   notifyListeners();
// }

// // 单聊消息操作
// Future<void> addSingleMessage(SingleMessage message) async {
//   if (_singleMessageDao == null) return;
//   await _singleMessageDao!.insertSingleMessage(message);
//   await _loadSingleMessages();
// }

// Future<void> updateSingleMessage(SingleMessage message) async {
//   if (_singleMessageDao == null) return;
//   await _singleMessageDao!.updateSingleMessage(message);
//   await _loadSingleMessages();
// }

// Future<void> deleteSingleMessage(SingleMessage message) async {
//   if (_singleMessageDao == null) return;
//   await _singleMessageDao!.deleteSingleMessage(message);
//   await _loadSingleMessages();
// }

// // 群聊消息操作
// Future<void> addGroupMessage(GroupMessage message) async {
//   if (_groupMessageDao == null) return;
//   await _groupMessageDao!.insertGroupMessage(message);
//   await _loadGroupMessages();
// }

// Future<void> updateGroupMessage(GroupMessage message) async {
//   if (_groupMessageDao == null) return;
//   await _groupMessageDao!.updateGroupMessage(message);
//   await _loadGroupMessages();
// }

// Future<void> deleteGroupMessage(GroupMessage message) async {
//   if (_groupMessageDao == null) return;
//   await _groupMessageDao!.deleteGroupMessage(message);
//   await _loadGroupMessages();
// }

// // 根据聊天ID获取消息
// List<SingleMessage> getSingleMessagesByChatId(int chatId) {
//   return _singleMessages.where((msg) => msg.chatId == chatId).toList();
// }

// List<GroupMessage> getGroupMessagesByChatId(int chatId) {
//   return _groupMessages.where((msg) => msg.chatId == chatId).toList();
// }
}
