import 'dart:convert';
import 'package:get/get.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../../config/app_config.dart';

class WebSocketStore extends GetxController {
  WebSocketChannel? _channel;
  bool _isConnecting = false;
  
  final RxBool isConnected = false.obs;
  
  Future<void> connect() async {
    if (isConnected.value || _isConnecting) return;
    
    _isConnecting = true;
    try {
      final wsUrl = Uri.parse('${AppConfig.wsServer}');
      _channel = WebSocketChannel.connect(wsUrl);
      
      _channel?.stream.listen(
        _handleMessage,
        onDone: _handleDisconnect,
        onError: (error) {
          print('WebSocket error: $error');
          _handleDisconnect();
        },
      );
      
      isConnected.value = true;
    } catch (e) {
      print('WebSocket connection failed: $e');
    } finally {
      _isConnecting = false;
    }
  }

  void disconnect() {
    _channel?.sink.close();
    _channel = null;
    isConnected.value = false;
  }

  void _handleDisconnect() {
    isConnected.value = false;
    _channel = null;
    // 可以在这里添加重连逻辑
  }

  void _handleMessage(dynamic message) {
    try {
      final Map<String, dynamic> data =
          message is String ? jsonDecode(message) : message;
          
      final String type = data['type'];
      
      switch (type) {
        case 'chat_message':
          Get.find<ChatController>().handleNewMessage(data['payload']);
          break;
        case 'user_status':
          Get.find<UserController>().handleStatusUpdate(data['payload']);
          break;
        // 可以添加更多消息类型的处理
      }
    } catch (e) {
      print('Error handling message: $e');
    }
  }

  void sendMessage(String type, Map<String, dynamic> payload) {
    if (!isConnected.value) return;
    
    final message = jsonEncode({
      'type': type,
      'payload': payload,
    });
    
    _channel?.sink.add(message);
  }

  @override
  void onClose() {
    disconnect();
    super.onClose();
  }
}
