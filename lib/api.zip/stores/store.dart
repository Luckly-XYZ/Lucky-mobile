// class Store {
//   late final WebSocketStore webSocketStore;
//   late final ChatStore chatStore;
//   late final UserStore userStore;
  
//   Store() {
//     webSocketStore = WebSocketStore(this);
//     chatStore = ChatStore(this);
//     userStore = UserStore(this);
//   }
  
//   Future<void> initialize() async {
//     // ... existing code ...
//     await webSocketStore.connect();
//   }
// } 