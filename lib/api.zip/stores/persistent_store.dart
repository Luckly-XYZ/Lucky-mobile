import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 通用的持久化 Store（支持多个 Store）
class PersistentStore extends ChangeNotifier {
  final String storeName; // 存储名称
  final List<String> persistFields; // 需要持久化的字段
  late SharedPreferences _prefs; // 共享偏好
  Map<String, dynamic> _state = {}; // 存储状态

  PersistentStore({required this.storeName, required this.persistFields}) {
    _init();
  }

  /// 初始化 SharedPreferences 并加载持久化数据
  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();
    String? storedData = _prefs.getString(storeName);
    if (storedData != null) {
      _state = jsonDecode(storedData);
    }
    notifyListeners();
  }

  /// 设置数据
  void set(String key, dynamic value) {
    _state[key] = value;
    if (persistFields.contains(key)) {
      _save();
    }
    notifyListeners();
  }

  /// 获取数据
  dynamic get(String key) {
    if (!_state.containsKey(key)) return null;

    var value = _state[key];

    // 如果值是 JSON 字符串，尝试解析
    if (value is! String) {
      try {
        return jsonDecode(value);
      } catch (e) {
        return value; // 不是 JSON，就直接返回
      }
    }

    return value;
  }

  /// 持久化到 SharedPreferences
  Future<void> _save() async {
    await _prefs.setString(storeName, jsonEncode(_state));
  }

  /// 清除数据
  Future<void> clear() async {
    _state.clear();
    await _prefs.remove(storeName);
    notifyListeners();
  }
}
