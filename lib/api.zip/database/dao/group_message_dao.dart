import 'package:floor/floor.dart';

@dao
abstract class GroupMessageDao {}
