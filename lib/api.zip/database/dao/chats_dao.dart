import 'package:floor/floor.dart';

import '../model/chats.dart';

@dao
abstract class ChatsDao {
  @Query('SELECT * FROM Chats')
  Future<List<Chats>> getAllChats();

// @Query('SELECT * FROM Chats WHERE id = :id')
// Future<Chats> getChatById(int id);
//
// @Query('SELECT * FROM Chats WHERE id = :id')
// Stream<Chats> getChatByIdStream(int id);

// @insert
// Future<void> insertChat(Chats chat);
//
// @update
// Future<void> updateChat(Chats chat);
//
// @delete
// Future<void> deleteChat(int id);
}
