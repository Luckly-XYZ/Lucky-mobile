import 'package:floor/floor.dart';

@dao
abstract class SingleMessageDao {
  // @Insert(onConflict: OnConflictStrategy.replace)
  // Future<List<int>> insertMessages(List<SingleMessage> messages);
  //
  // @Query(
  //     'SELECT * FROM single_messages WHERE chatId = :chatId ORDER BY createdAt DESC LIMIT :limit OFFSET :offset')
  // Future<List<SingleMessage>> getMessagesByChatId(int chatId,
  //     {int limit = 20, int offset = 0});
  //
  // @Query(
  //     'SELECT * FROM single_messages WHERE content LIKE :keyword ORDER BY createdAt DESC')
  // Future<List<SingleMessage>> searchMessages(String keyword);
  //
  // @Query('SELECT COUNT(*) FROM single_messages WHERE chatId = :chatId')
  // Future<int> getMessageCount(int chatId);
}
