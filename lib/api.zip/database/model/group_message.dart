import 'package:floor/floor.dart';

@Entity(tableName: 'group_message') // Entity 注解，指定表名为 'Chats'
class GroupMessage {
  @primaryKey
  String message_id;
  String from_id;
  String owner_id;
  String group_id;
  String message_body;
  String message_content_type;
  int message_time;
  String message_type;
  int read_status;
  int sequence;
  String extra;

  GroupMessage({
    required this.message_id,
    required this.from_id,
    required this.owner_id,
    required this.group_id,
    required this.message_body,
    required this.message_content_type,
    required this.message_time,
    required this.message_type,
    required this.read_status,
    required this.sequence,
    required this.extra,
  });

  Map<String, dynamic> toJson() {
    return {
      'message_id': message_id,
      'from_id': from_id,
      'owner_id': owner_id,
      'group_id': group_id,
      'message_body': message_body,
      'message_content_type': message_content_type,
      'message_time': message_time,
      'message_type': message_type,
      'read_status': read_status,
      'sequence': sequence,
      'extra': extra,
    };
  }

  factory GroupMessage.fromJson(Map<String, dynamic> json) {
    return GroupMessage(
      message_id: json['message_id'] as String,
      from_id: json['from_id'] as String,
      owner_id: json['owner_id'] as String,
      group_id: json['group_id'] as String,
      message_body: json['message_body'] as String,
      message_content_type: json['message_content_type'] as String,
      message_time: json['message_time'] as int,
      message_type: json['message_type'] as String,
      read_status: json['read_status'] as int,
      sequence: json['sequence'] as int,
      extra: json['extra'] as String,
    );
  }
}
