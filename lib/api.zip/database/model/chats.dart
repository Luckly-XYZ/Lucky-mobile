import 'package:floor/floor.dart';

import '../BaseObject.dart';

@Entity(tableName: 'chats', indices: [
  Index(value: ['chat_id', 'name'])
]) // Entity 注解，指定表名为 'Chats'  Index 索引
class Chats extends BaseObject {
  @primaryKey
  int chat_id;

  //@ColumnInfo(name: 'custom_name') 自定义列名
  //@ignore // Ignore 注解，指定字段将被忽略
  int chat_type; // 消息类型
  String owner_id; // 归属人
  String to_id; // 接收人
  int is_mute; // 免打扰
  int is_top; // 置顶
  int sequence; // 新增字段
  String name; // 名称
  String avatar; // 头像
  int unread = 0; // 消息数
  String id; // 消息id
  String message; // 消息
  int message_time; // 消息时间

  Chats(
      this.chat_id,
      this.chat_type,
      this.owner_id,
      this.to_id,
      this.is_mute,
      this.is_top,
      this.sequence,
      this.name,
      this.avatar,
      this.unread,
      this.id,
      this.message,
      this.message_time); // 消息时间

  Map<String, dynamic> toJson() {
    return {
      'chat_id': chat_id,
      'chat_type': chat_type,
      'owner_id': owner_id,
      'to_id': to_id,
      'is_mute': is_mute,
      'is_top': is_top,
      'sequence': sequence,
      'name': name,
      'avatar': avatar,
      'unread': unread,
      'id': id,
      'message': message,
      'message_time': message_time,
    };
  }

  factory Chats.fromJson(Map<String, dynamic> json) {
    return Chats(
      json['chat_id'] as int,
      json['chat_type'] as int,
      json['owner_id'] as String,
      json['to_id'] as String,
      json['is_mute'] as int,
      json['is_top'] as int,
      json['sequence'] as int,
      json['name'] as String,
      json['avatar'] as String,
      json['unread'] as int,
      json['id'] as String,
      json['message'] as String,
      json['message_time'] as int,
    );
  }
}
