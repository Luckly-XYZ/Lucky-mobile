

abstract class BaseObject {
  // DateTime createdAt = DateTime.now();
  // DateTime updatedAt = DateTime.now();
  //
  // // 添加更新时间的方法
  // void updateTimestamp() {
  //   updatedAt = DateTime.now();
  // }
}
