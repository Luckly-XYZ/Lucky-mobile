import 'dart:async';
import 'dart:convert';

import 'package:get/get.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class WebSocketService extends GetxService {
  static const String _wsUrl =
      'ws://your-websocket-server-url'; // 替换为实际的WebSocket服务器地址
  static const int _heartbeatInterval = 30; // 心跳间隔（秒）
  static const int _reconnectDelay = 5; // 重连延迟（秒）

  WebSocketChannel? _channel;
  Timer? _heartbeatTimer;
  Timer? _reconnectTimer;
  bool _isConnected = false;
  final _messageController = StreamController<dynamic>.broadcast();

  // 消息流
  Stream<dynamic> get messageStream => _messageController.stream;

  // 连接状态
  bool get isConnected => _isConnected;

  // 初始化连接
  Future<void> connect() async {
    if (_isConnected) return;

    try {
      _channel = WebSocketChannel.connect(Uri.parse(_wsUrl));
      _isConnected = true;

      // 监听消息
      _channel!.stream.listen(
        (message) {
          _handleMessage(message);
        },
        onError: (error) {
          print('WebSocket错误: $error');
          _handleDisconnect();
        },
        onDone: () {
          print('WebSocket连接关闭');
          _handleDisconnect();
        },
      );

      // 启动心跳
      _startHeartbeat();
    } catch (e) {
      print('WebSocket连接失败: $e');
      _handleDisconnect();
    }
  }

  // 处理接收到的消息
  void _handleMessage(dynamic message) {
    try {
      final data = jsonDecode(message);

      // 处理心跳响应
      if (data['type'] == 'pong') {
        return;
      }

      // 广播消息给监听器
      _messageController.add(data);
    } catch (e) {
      print('消息解析错误: $e');
    }
  }

  // 发送消息
  void sendMessage(Map<String, dynamic> message) {
    if (!_isConnected) return;

    try {
      final jsonMessage = jsonEncode(message);
      _channel?.sink.add(jsonMessage);
    } catch (e) {
      print('发送消息失败: $e');
    }
  }

  // 启动心跳
  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(
      const Duration(seconds: _heartbeatInterval),
      (_) => _sendHeartbeat(),
    );
  }

  // 发送心跳
  void _sendHeartbeat() {
    sendMessage({'type': 'ping'});
  }

  // 处理断开连接
  void _handleDisconnect() {
    _isConnected = false;
    _heartbeatTimer?.cancel();
    _channel?.sink.close();
    _startReconnect();
  }

  // 开始重连
  void _startReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer.periodic(
      const Duration(seconds: _reconnectDelay),
      (_) {
        if (!_isConnected) {
          print('尝试重新连接...');
          connect();
        } else {
          _reconnectTimer?.cancel();
        }
      },
    );
  }

  // 关闭连接
  void dispose() {
    _isConnected = false;
    _heartbeatTimer?.cancel();
    _reconnectTimer?.cancel();
    _channel?.sink.close();
    _messageController.close();
  }
}
