import 'package:flutter/material.dart';

const Color kColor33 = Color(0xFF333333);
const Color kColor99 = Color(0xFF999999);
const Color kColorF1A33A = Color(0xFFF1A33A);
const Color kColorE86A3E = Color(0xFFE86A3E);
const Color kColorECEDED = Color(0xFFECEDED);
