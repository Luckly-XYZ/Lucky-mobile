import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// WebViewPage 页面，用于加载指定 URL 的网页，并在 AppBar 显示网页标题
class WebViewPage extends StatefulWidget {
  // 访问 url
  final String url;

  const WebViewPage({Key? key, required this.url}) : super(key: key);

  @override
  State<WebViewPage> createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  late final WebViewController _controller;
  String _title = "";

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) async {
            final titleResult = await _controller
                .runJavaScriptReturningResult("document.title");
            String title = titleResult.toString();
            if (title.startsWith('"') && title.endsWith('"')) {
              title = title.substring(1, title.length - 1);
            }
            setState(() {
              _title = title;
            });
          },
          onNavigationRequest: (NavigationRequest request) async {
            final uri = Uri.parse(request.url);

            // 检查 URL Scheme
            if (uri.scheme != 'http' || uri.scheme != 'https') {
              // 对于 HTTP 和 HTTPS 链接，尝试使用外部浏览器打开
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
                return NavigationDecision.prevent;
              } else {
                // 如果无法使用外部浏览器打开，则在 WebView 中加载
                return NavigationDecision.navigate;
              }
            } else if (uri.scheme == 'mailto' || uri.scheme == 'tel') {
              // 处理邮件链接
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri);
                return NavigationDecision.prevent;
              } else {
                // 无法处理的 mailto 链接，您可以显示错误或采取其他措施
                return NavigationDecision.prevent;
              }
            } else {
              // 对于其他非标准协议，您可以根据需要添加更多处理逻辑
              // 或者选择在 WebView 中加载
              return NavigationDecision.navigate;
            }
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_title),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: WebViewWidget(controller: _controller),
    );
  }
}
