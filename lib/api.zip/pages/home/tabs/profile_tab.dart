import 'package:flutter/material.dart';
import 'package:flutter_im/constants/app_sizes.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../../routes/app_routes.dart';
import '../../../stores/impl/user_store.dart';
import '../../scan/scan_page.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  void _loginOut(BuildContext context) {
    Provider.of<UserStore>(context, listen: false).logout();
    Get.offAllNamed(AppRoutes.LOGIN);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            Consumer<UserStore>(
              builder: (context, userStore, child) {
                final userInfo = userStore.userInfo;
                String username = userInfo['name'] ?? '未登录';
                String signature = userInfo['self_signature'] ?? '这个人很神秘...';
                String avatarUrl = userInfo['avatar'] ?? '';
                String userSex = userInfo['user_sex'] ?? '';

                Icon? genderIcon;
                if (userSex == '1') {
                  genderIcon =
                      const Icon(Icons.male, color: Colors.blue, size: 18);
                } else if (userSex == '0') {
                  genderIcon =
                      const Icon(Icons.female, color: Colors.pink, size: 18);
                }

                return Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                  color: Colors.white,
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Container(
                          width: 50,
                          height: 50,
                          color: Colors.grey[300],
                          child: avatarUrl.isNotEmpty
                              ? Image.network(
                                  avatarUrl,
                                  fit: BoxFit.cover,
                                )
                              : const Icon(Icons.person,
                                  size: 45, color: Colors.white),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(username,
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(width: 5),
                                if (genderIcon != null) genderIcon,
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(signature,
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 14)),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.qr_code, size: kSize22),
                        onPressed: () {
                          Get.toNamed(AppRoutes.PROFILE_QR_CODE);
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            Container(
              color: Colors.white,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.qr_code_scanner,
                        color: Colors.black87),
                    title: const Text('扫一扫'),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (context) => const ScanPage()),
                      );
                    },
                  ),
                  //const Divider(height: 1, indent: 16, endIndent: 16),
                  ListTile(
                    leading: const Icon(Icons.settings, color: Colors.black87),
                    title: const Text('设置'),
                    onTap: () {
                      // TODO: 实现设置页面导航
                      Get.toNamed(AppRoutes.SETTINGS);
                    },
                  ),
                  //const Divider(height: 1, indent: 16, endIndent: 16),
                  ListTile(
                    leading:
                        const Icon(Icons.exit_to_app, color: Colors.black87),
                    title: const Text('退出登录'),
                    onTap: () {
                      _loginOut(context);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
