import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'home_controller.dart';
import 'tabs/chat_tab.dart';
import 'tabs/profile_tab.dart';

class HomePage extends GetView<HomeController> {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // 确保控制器已注册
    Get.put(HomeController());

    return Scaffold(
      body: Obx(() => IndexedStack(
            index: controller.currentIndex,
            children: const [
              ChatTab(), // 消息
              ProfileTab(), // 我的
            ],
          )),
      bottomNavigationBar: Obx(
        () => BottomNavigationBar(
          currentIndex: controller.currentIndex,
          onTap: controller.changeTabIndex,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.message),
              label: '消息',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: '我的',
            ),
          ],
        ),
      ),
    );
  }
}
