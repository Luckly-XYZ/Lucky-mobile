import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // 用于震动反馈
import 'package:flutter_im/constants/app_constant.dart';
import 'package:get/get.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../utils/audio.dart';
import '../../utils/url_util.dart';
import '../common/webview_page.dart';
import 'login_authorization_page.dart';

class ScanPage extends StatefulWidget {
  const ScanPage({Key? key}) : super(key: key);

  @override
  _ScanPageState createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  final MobileScannerController controller = MobileScannerController();
  bool isTorchOn = false; // 闪光灯状态
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    // 设置强制竖屏
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);

    // 添加应用生命周期监听
    WidgetsBinding.instance.addObserver(this);
    // 启动相机
    controller.start();

    // 初始化动画控制器
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
  }

  @override
  void dispose() {
    // 移除应用生命周期监听
    WidgetsBinding.instance.removeObserver(this);
    // 停止相机并释放资源
    controller.dispose();
    _animationController.dispose();
    super.dispose();
  }

  // 监听应用生命周期变化
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!mounted) return;

    switch (state) {
      case AppLifecycleState.resumed:
        // 应用从后台恢复时，启动相机
        if (!controller.isStarting) {
          controller.start();
        }
        break;
      case AppLifecycleState.inactive:
      case AppLifecycleState.paused:
        // 应用进入后台或暂停时，停止相机
        if (controller.isStarting) {
          controller.stop();
        }
        break;
      default:
        break;
    }
  }

  // 条码检测回调
  void onBarcodeDetected(BarcodeCapture capture) {
    final List<Barcode> barcodes = capture.barcodes;
    if (barcodes.isNotEmpty) {
      final String? code = barcodes.first.rawValue;
      if (code != null) {
        debugPrint('扫码结果: $code');
        // 触发中等强度的震动反馈
        HapticFeedback.mediumImpact();

        // 播放音频
        AudioPlayerUtil().play('audio/beep.mp3', useMediaVolume: false);

        // 使用工具类判断是否是URL
        if (UrlUtil.isValidUrl(code)) {
          controller.stop();
          Get.to(() => WebViewPage(url: code))?.then((_) {
            if (mounted) {
              controller.start();
            }
          }).catchError((err) {
            Get.back();
          });
          return;
        }

        // 如果二维码内容以指定前缀开头，则导航到授权页面
        if (code.startsWith(AppConstants.LOGIN_QRCODE_PREFIX)) {
          // 确保导航操作的幂等性
          if (ModalRoute.of(context)?.settings.name != '/authorization') {
            // 停止相机
            controller.stop();
            Get.to(() => AuthorizationPage(code: code))?.then((_) {
              // 页面返回时重新启动相机
              if (mounted) {
                controller.start();
              }
            }).catchError((err) {
              Get.back();
            });
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Stack(
        children: [
          // 显示扫描界面
          MobileScanner(
            controller: controller,
            onDetect: onBarcodeDetected,
          ),
          // 左上角的返回按钮
          Positioned(
            top: MediaQuery.of(context).padding.top + 10,
            left: 16,
            child: IconButton(
              icon: const Icon(
                Icons.close,
                color: Colors.white,
                size: 24,
              ),
              onPressed: () {
                Get.back();
              },
            ),
          ),
          // 居中绘制扫描区域的边框
          Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                // 移除原来的Container，改用SizedBox来控制大小
                const SizedBox(
                  width: 250,
                  height: 250,
                ),
                // 添加扫描线动画
                AnimatedBuilder(
                  animation: _animationController,
                  builder: (context, child) {
                    return Positioned(
                      top: _animationController.value * 250,
                      child: Container(
                        width: 230,
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                            colors: [
                              Colors.green.withOpacity(0),
                              Colors.green.withOpacity(0.5),
                              Colors.green,
                              Colors.green.withOpacity(0.5),
                              Colors.green.withOpacity(0),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
                // 左上角
                Positioned(
                  left: 0,
                  top: 0,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: const BoxDecoration(
                      border: Border(
                        left: BorderSide(color: Colors.green, width: 4),
                        top: BorderSide(color: Colors.green, width: 4),
                      ),
                    ),
                  ),
                ),
                // 右上角
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: const BoxDecoration(
                      border: Border(
                        right: BorderSide(color: Colors.green, width: 4),
                        top: BorderSide(color: Colors.green, width: 4),
                      ),
                    ),
                  ),
                ),
                // 左下角
                Positioned(
                  left: 0,
                  bottom: 0,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: const BoxDecoration(
                      border: Border(
                        left: BorderSide(color: Colors.green, width: 4),
                        bottom: BorderSide(color: Colors.green, width: 4),
                      ),
                    ),
                  ),
                ),
                // 右下角
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: const BoxDecoration(
                      border: Border(
                        right: BorderSide(color: Colors.green, width: 4),
                        bottom: BorderSide(color: Colors.green, width: 4),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // 闪光灯图标位于扫描区域下方
          Positioned(
            top: screenHeight / 2 + 140,
            left: 0,
            right: 0,
            child: Center(
              child: IconButton(
                iconSize: 40,
                icon: Icon(
                  isTorchOn ? Icons.flash_on : Icons.flash_off,
                  color:
                      isTorchOn ? Colors.amber[400] : Colors.white, // 打开时显示金黄色
                ),
                onPressed: () {
                  setState(() {
                    isTorchOn = !isTorchOn;
                    controller.toggleTorch();
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
