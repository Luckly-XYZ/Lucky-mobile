import 'package:flutter/material.dart';
import 'package:flutter_im/pages/auth/login_controller.dart';
import 'package:flutter_im/stores/impl/user_store.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class LoginPage extends GetView<LoginController> {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    // 确保控制器已注册
    Get.put(LoginController());

    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.fromLTRB(
              24.0,
              MediaQuery.of(context).size.height * 0.1, // 调整顶部间距
              24.0,
              24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildAvatar(context),
              const SizedBox(height: 24), // 减小间距
              _buildLoginForm(context),
              const SizedBox(height: 16),
              _buildSwitchAuthTypeRow(context),
            ],
          ),
        ),
      ),
      resizeToAvoidBottomInset: true, // 改为 true
    );
  }

  Widget _buildAvatar(BuildContext context) {
    return Consumer<UserStore>(
      builder: (context, userStore, child) {
        final String? avatarUrl = userStore.userInfo['avatar'];
        if (avatarUrl == null || avatarUrl.isEmpty) {
          return const SizedBox.shrink();
        }
        return Center(
          child: Column(
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.grey[300]!,
                    width: 2,
                  ),
                  image: DecorationImage(
                    image: NetworkImage(avatarUrl),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSwitchAuthTypeRow(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          controller.currentAuthType == AuthType.password ? '还没有账号？' : '已有账号？',
          style: TextStyle(color: Colors.grey[600]),
        ),
        TextButton(
          onPressed: () {
            controller.tabController.animateTo(
              controller.currentAuthType == AuthType.password ? 1 : 0,
            );
          },
          child: Text(
            controller.currentAuthType == AuthType.password
                ? '手机号登录'
                : '账号密码登录',
          ),
        ),
      ],
    );
  }

  Widget _buildLoginForm(BuildContext context) {
    final bool isPasswordMode = controller.currentAuthType == AuthType.password;
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 10,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: controller.principalController,
            decoration: InputDecoration(
              labelText: isPasswordMode ? '账号' : '手机号',
              border: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: const BorderRadius.all(Radius.circular(12)),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: const BorderRadius.all(Radius.circular(12)),
                borderSide: BorderSide(color: theme.primaryColor),
              ),
              prefixIcon: Icon(
                isPasswordMode ? Icons.person : Icons.phone,
                color: Colors.grey[600],
              ),
              filled: true,
              fillColor: Colors.grey[50],
            ),
            keyboardType:
                isPasswordMode ? TextInputType.text : TextInputType.phone,
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller.credentialsController,
                  decoration: InputDecoration(
                    labelText: isPasswordMode ? '密码' : '验证码',
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: const BorderRadius.all(Radius.circular(12)),
                      borderSide: BorderSide(color: Colors.grey[300]!),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: const BorderRadius.all(Radius.circular(12)),
                      borderSide: BorderSide(color: theme.primaryColor),
                    ),
                    prefixIcon: Icon(
                      isPasswordMode ? Icons.lock : Icons.security,
                      color: Colors.grey[600],
                    ),
                    filled: true,
                    fillColor: Colors.grey[50],
                  ),
                  obscureText: isPasswordMode,
                  keyboardType: isPasswordMode
                      ? TextInputType.text
                      : TextInputType.number,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => controller.handleLogin(),
                ),
              ),
              if (!isPasswordMode) ...[
                const SizedBox(width: 16),
                SizedBox(
                  width: 120,
                  child: ElevatedButton(
                    onPressed: controller.canSendCode.value
                        ? controller.sendVerificationCode
                        : null,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      disabledBackgroundColor: Colors.grey[300],
                      disabledForegroundColor: Colors.grey[600],
                    ),
                    child: Text(
                      controller.canSendCode.value
                          ? '发送验证码'
                          : '${controller.countDown}s',
                    ),
                  ),
                ),
              ],
            ],
          ),
          if (isPasswordMode) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Obx(() => Checkbox(
                      value: controller.rememberCredentials.value,
                      onChanged: (value) {
                        controller.rememberCredentials.value = value ?? false;
                      },
                    )),
                GestureDetector(
                  onTap: () {
                    controller.rememberCredentials.value =
                        !controller.rememberCredentials.value;
                  },
                  child: const Text('记住密码'),
                ),
              ],
            ),
          ],
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed:
                  controller.isLoading.value ? null : controller.handleLogin,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: controller.isLoading.value
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : const Text(
                      '登录',
                      style: TextStyle(fontSize: 16),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
