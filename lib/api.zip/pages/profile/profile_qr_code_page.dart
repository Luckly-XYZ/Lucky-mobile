import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../stores/impl/user_store.dart';

class ProfileQRCodePage extends StatelessWidget {
  const ProfileQRCodePage({super.key});

  @override
  Widget build(BuildContext context) {
    const qrSize = 240.0; // 增加二维码尺寸
    const containerPadding = 10.0;
    const containerWidth = qrSize + (containerPadding * 2);

    return Scaffold(
      appBar: AppBar(
        title: const Text('我的二维码'),
        centerTitle: true,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Consumer<UserStore>(
        builder: (context, userStore, child) {
          final userInfo = userStore.userInfo;
          String username = userInfo['name'] ?? '未登录';
          String avatarUrl = userInfo['avatar'] ?? '';
          String userId = userInfo['user_id']?.toString() ?? '';

          // 构建简化的二维码数据
          final qrData = {
            'userId': userId,
            'type': 'friend',
          };

          return Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 40),
                // 用户信息区域
                Row(
                  children: [
                    // 矩形头像
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Container(
                        width: 50,
                        height: 50,
                        color: Colors.grey[300],
                        child: avatarUrl.isNotEmpty
                            ? Image.network(
                                avatarUrl,
                                fit: BoxFit.cover,
                              )
                            : const Icon(
                                Icons.person,
                                size: 40,
                                color: Colors.white,
                              ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    // 用户名
                    Text(
                      username,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                // 二维码
                Center(
                  child: Container(
                    width: containerWidth,
                    padding: const EdgeInsets.all(containerPadding),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: QrImageView(
                      data: Uri.encodeComponent(qrData.toString()),
                      version: QrVersions.auto,
                      size: qrSize,
                      backgroundColor: Colors.white,
                      embeddedImage: NetworkImage(avatarUrl),
                      embeddedImageStyle: const QrEmbeddedImageStyle(
                        size: Size(36, 36), // 相应增加嵌入图片的大小
                      ),
                      errorCorrectionLevel: QrErrorCorrectLevel.M,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // 提示文字居中
                const Center(
                  child: Text(
                    '扫一扫上面的二维码，加我为好友',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
