import 'dart:math';

import 'package:get/get.dart';
import '../models/message_model.dart';

class MessageController extends GetxController {
  final messages = <MessageModel>[].obs;

  @override
  void onInit() {
    super.onInit();
    // 加载示例数据
    loadMessages();
  }

  void loadMessages() {
    final random = Random();
    final sampleMessages = [
      '你好！',
      '最近怎么样？',
      '今天天气真好。',
      '你看了昨天的比赛吗？',
      '有什么新电影推荐吗？',
      '这个周末有什么计划？',
      '工作进展如何？',
      '听说你最近去了旅行，感觉如何？',
    ];

    final usernames = ['张三', '李四', '王五', '赵六', '孙七', '周八', '吴九', '郑十'];
    final avatarUrls = [
      'https://img0.baidu.com/it/u=1472806772,699408928&fm=253&fmt=auto&app=120&f=JPEG?w=500&h=500',
    ];

    for (int i = 0; i < 500; i++) {
      final isMe = random.nextBool();
      final username = isMe ? '我' : usernames[random.nextInt(usernames.length)];
      final avatarUrl = avatarUrls[random.nextInt(avatarUrls.length)];
      final message = sampleMessages[random.nextInt(sampleMessages.length)];
      final timestamp = DateTime.now().subtract(
          Duration(minutes: random.nextInt(60), seconds: random.nextInt(60)));

      messages.add(MessageModel(
        message: message,
        isMe: isMe,
        avatarUrl: avatarUrl,
        timestamp: timestamp,
        username: username,
      ));
    }
  }

  void sendMessage(String message) {
    if (message.trim().isEmpty) return;

    messages.add(MessageModel(
      message: message,
      isMe: true,
      avatarUrl: 'https://example.com/avatar2.jpg',
      timestamp: DateTime.now(),
      username: '我',
    ));
  }
}
