class MessageModel {
  final String message;
  final bool isMe;
  final String avatarUrl;
  final DateTime timestamp;
  final String username;

  MessageModel({
    required this.message,
    required this.isMe,
    required this.avatarUrl,
    required this.timestamp,
    required this.username,
  });
} 