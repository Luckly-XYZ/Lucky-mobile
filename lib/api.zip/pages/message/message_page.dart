import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controllers/message_controller.dart';
import 'message_bubble.dart';
import 'widgets/message_input.dart';

class MessagePage extends StatelessWidget {
  final MessageController controller = Get.put(MessageController());
  final TextEditingController textController = TextEditingController();

  MessagePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Column(
          children: [
            Text(
              '张三', // 会话用户名
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Obx(
              () => ListView.builder(
                itemCount: controller.messages.length,
                itemBuilder: (context, index) {
                  return MessageBubble(
                    message: controller.messages[index],
                  );
                },
              ),
            ),
          ),
          MessageInput(
            controller: controller,
            textController: textController,
          ),
        ],
      ),
    );
  }
}
