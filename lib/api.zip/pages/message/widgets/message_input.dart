import 'package:flutter/material.dart';
import '../controllers/message_controller.dart';
import '../../../components/emoji/emoji_picker.dart';

class MessageInput extends StatefulWidget {
  final MessageController controller;
  final TextEditingController textController;

  const MessageInput({
    Key? key,
    required this.controller,
    required this.textController,
  }) : super(key: key);

  @override
  State<MessageInput> createState() => _MessageInputState();
}

class _MessageInputState extends State<MessageInput> {
  bool _showEmojiPicker = false;
  bool _hasText = false;

  late TextEditingController _richTextController;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _richTextController = TextEditingController();
    _richTextController.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _richTextController.removeListener(_onTextChanged);
    _richTextController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    final hasText = _richTextController.text.trim().isNotEmpty;
    if (hasText != _hasText) {
      setState(() {
        _hasText = hasText;
      });
    }
  }

  void _insertEmoji(String emoji) {
    final text = _richTextController.text;
    final selection = _richTextController.selection;
    final newText = text.replaceRange(
      selection.start,
      selection.end,
      emoji,
    );
    _richTextController.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(
        offset: selection.baseOffset + emoji.length,
      ),
    );
  }

  String _getRichText() {
    return _richTextController.text;
  }

  void _toggleEmojiPicker() {
    setState(() {
      _showEmojiPicker = !_showEmojiPicker;
      if (_showEmojiPicker) {
        _focusNode.requestFocus();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.only(
            left: 16,
            right: 8,
            top: 4,
            bottom: 4,
          ),
          child: Row(
            children: [
              Expanded(
                child: Container(
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: const Color.fromARGB(255, 222, 217, 217),
                      width: 1,
                    ),
                  ),
                  child: TextField(
                    controller: _richTextController,
                    focusNode: _focusNode,
                    decoration: const InputDecoration(
                      hintText: '输入消息...',
                      hintStyle: TextStyle(fontSize: 14),
                      border: InputBorder.none,
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                    ),
                    style: const TextStyle(fontSize: 14),
                    maxLines: 1,
                    textAlignVertical: TextAlignVertical.center,
                    enableInteractiveSelection: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Stack(
                alignment: Alignment.center,
                children: [
                  Visibility(
                    visible: !_hasText,
                    maintainSize: true,
                    maintainAnimation: true,
                    maintainState: true,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 36,
                          child: IconButton(
                            onPressed: _toggleEmojiPicker,
                            icon: Icon(
                              Icons.emoji_emotions_outlined,
                              color: Colors.grey[600],
                              size: 30,
                            ),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(
                              minWidth: 32,
                              minHeight: 36,
                            ),
                          ),
                        ),
                        const SizedBox(width: 2),
                        SizedBox(
                          width: 36,
                          child: IconButton(
                            onPressed: () {
                              // TODO: 实现加号按钮功能
                            },
                            icon: Icon(
                              Icons.add_circle_outline,
                              color: Colors.grey[600],
                              size: 30,
                            ),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(
                              minWidth: 32,
                              minHeight: 36,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Visibility(
                    visible: _hasText,
                    maintainSize: true,
                    maintainAnimation: true,
                    maintainState: true,
                    child: SizedBox(
                      width: 74,
                      height: 36,
                      child: TextButton(
                        onPressed: () {
                          final text = _getRichText().trim();
                          if (text.isNotEmpty) {
                            widget.controller.sendMessage(text);
                            _richTextController.clear();
                          }
                        },
                        style: TextButton.styleFrom(
                          backgroundColor: Theme.of(context).primaryColor,
                          padding: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        child: const Text(
                          '发送',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        if (_showEmojiPicker)
          SizedBox(
            height: 250,
            child: EmojiPicker(
              onEmojiSelected: (emoji) {
                _insertEmoji(emoji);
              },
            ),
          ),
      ],
    );
  }
}
