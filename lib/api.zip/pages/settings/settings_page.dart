import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'settings_controller.dart';

class SettingsPage extends GetView<SettingsController> {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // 确保控制器已注册
    Get.put(SettingsController());
    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
      ),
      body: Obx(
        () => ListView(
          children: [
            _buildSection(
              '账号设置',
              [
                ListTile(
                  leading: const Icon(Icons.person_outline),
                  title: const Text('个人资料'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: controller.onProfileTap,
                ),
                ListTile(
                  leading: const Icon(Icons.security),
                  title: const Text('账号安全'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: controller.onSecurityTap,
                ),
              ],
            ),
            _buildSection(
              '通知设置',
              [
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_none),
                  title: const Text('新消息通知'),
                  value: controller.messageNotification.value,
                  onChanged: controller.toggleMessageNotification,
                ),
                SwitchListTile(
                  secondary: const Icon(Icons.vibration),
                  title: const Text('震动'),
                  value: controller.vibration.value,
                  onChanged: controller.toggleVibration,
                ),
                SwitchListTile(
                  secondary: const Icon(Icons.volume_up_outlined),
                  title: const Text('声音'),
                  value: controller.sound.value,
                  onChanged: controller.toggleSound,
                ),
              ],
            ),
            _buildSection(
              '隐私设置',
              [
                ListTile(
                  leading: const Icon(Icons.block),
                  title: const Text('黑名单'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: controller.onBlockListTap,
                ),
                SwitchListTile(
                  secondary: const Icon(Icons.visibility),
                  title: const Text('在线状态可见'),
                  value: controller.onlineStatusVisible.value,
                  onChanged: controller.toggleOnlineStatusVisible,
                ),
              ],
            ),
            _buildSection(
              '通用设置',
              [
                ListTile(
                  leading: const Icon(Icons.storage_outlined),
                  title: const Text('清除缓存'),
                  trailing: Text(controller.cacheSize.value),
                  onTap: controller.clearCache,
                ),
                ListTile(
                  leading: const Icon(Icons.language),
                  title: const Text('语言'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(controller.currentLanguage.value),
                      const Icon(Icons.chevron_right),
                    ],
                  ),
                  onTap: controller.onLanguageTap,
                ),
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: const Text('关于'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: controller.onAboutTap,
                ),
              ],
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ElevatedButton(
                onPressed: controller.logout,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                child: const Text('退出登录'),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        ...children,
        const Divider(),
      ],
    );
  }
}
