import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SettingsController extends GetxController {
  // 通知设置
  final messageNotification = true.obs;
  final vibration = true.obs;
  final sound = true.obs;

  // 隐私设置
  final onlineStatusVisible = true.obs;

  // 通用设置
  final cacheSize = '23.5MB'.obs;
  final currentLanguage = '简体中文'.obs;

  void toggleMessageNotification(bool value) {
    messageNotification.value = value;
    // TODO: 保存设置
  }

  void toggleVibration(bool value) {
    vibration.value = value;
    // TODO: 保存设置
  }

  void toggleSound(bool value) {
    sound.value = value;
    // TODO: 保存设置
  }

  void toggleOnlineStatusVisible(bool value) {
    onlineStatusVisible.value = value;
    // TODO: 保存设置并更新服务器
  }

  void onProfileTap() {
    // TODO: 导航到个人资料页面
    Get.toNamed('/profile');
  }

  void onSecurityTap() {
    // TODO: 导航到账号安全页面
    Get.toNamed('/security');
  }

  void onBlockListTap() {
    // TODO: 导航到黑名单页面
    Get.toNamed('/blocklist');
  }

  void clearCache() async {
    // TODO: 实现清除缓存逻辑
    Get.dialog(
      AlertDialog(
        title: const Text('清除缓存'),
        content: const Text('确定要清除缓存吗？'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              // TODO: 执行清除缓存
              cacheSize.value = '0B';
              Get.back();
              Get.snackbar('提示', '缓存已清除');
            },
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }

  void onLanguageTap() {
    // TODO: 显示语言选择对话框
    Get.dialog(
      AlertDialog(
        title: const Text('选择语言'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('简体中文'),
              onTap: () {
                currentLanguage.value = '简体中文';
                Get.back();
              },
            ),
            ListTile(
              title: const Text('English'),
              onTap: () {
                currentLanguage.value = 'English';
                Get.back();
              },
            ),
          ],
        ),
      ),
    );
  }

  void onAboutTap() {
    // TODO: 导航到关于页面
    Get.toNamed('/about');
  }

  void logout() {
    Get.dialog(
      AlertDialog(
        title: const Text('退出登录'),
        content: const Text('确定要退出登录吗？'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              // TODO: 执行退出登录逻辑
              Get.offAllNamed('/login');
            },
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }
}
