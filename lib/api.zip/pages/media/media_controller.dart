import 'package:audioplayers/audioplayers.dart';
import 'package:get/get.dart';
import 'package:video_player/video_player.dart';

class MediaController extends GetxController {
  final String mediaUrl;
  final MediaType mediaType;

  MediaController({required this.mediaUrl, required this.mediaType});

  late AudioPlayer audioPlayer;
  VideoPlayerController? videoController;

  final isPlaying = false.obs;
  final duration = Duration.zero.obs;
  final position = Duration.zero.obs;

  @override
  void onInit() {
    super.onInit();
    _initializePlayer();
  }

  void _initializePlayer() async {
    switch (mediaType) {
      case MediaType.audio:
        audioPlayer = AudioPlayer();
        await audioPlayer.setSource(UrlSource(mediaUrl));

        audioPlayer.onDurationChanged.listen((newDuration) {
          duration.value = newDuration;
        });

        audioPlayer.onPositionChanged.listen((newPosition) {
          position.value = newPosition;
        });

        audioPlayer.onPlayerComplete.listen((_) {
          isPlaying.value = false;
        });
        break;

      case MediaType.video:
        videoController = VideoPlayerController.network(mediaUrl)
          ..initialize().then((_) {
            update();
          });
        break;

      case MediaType.image:
        // 图片不需要特殊初始化
        break;
    }
  }

  void toggleAudioPlayPause() async {
    if (isPlaying.value) {
      await audioPlayer.pause();
    } else {
      await audioPlayer.resume();
    }
    isPlaying.value = !isPlaying.value;
  }

  void toggleVideoPlayPause() {
    if (videoController?.value.isPlaying ?? false) {
      videoController?.pause();
    } else {
      videoController?.play();
    }
    update();
  }

  void seekAudio(Duration position) async {
    await audioPlayer.seek(position);
  }

  @override
  void onClose() {
    if (mediaType == MediaType.audio) {
      audioPlayer.dispose();
    } else if (mediaType == MediaType.video) {
      videoController?.dispose();
    }
    super.onClose();
  }
}

enum MediaType {
  image,
  video,
  audio,
}
