import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:photo_view/photo_view.dart';
import 'package:video_player/video_player.dart';

import 'media_controller.dart';

class MediaViewerPage extends GetView<MediaController> {
  const MediaViewerPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_getTitle()),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
      ),
      body: Center(
        child: _buildMediaContent(),
      ),
    );
  }

  Widget _buildMediaContent() {
    switch (controller.mediaType) {
      case MediaType.image:
        return PhotoView(
          imageProvider: NetworkImage(controller.mediaUrl),
          minScale: PhotoViewComputedScale.contained,
          maxScale: PhotoViewComputedScale.covered * 2,
        );

      case MediaType.video:
        return GetBuilder<MediaController>(
          builder: (_) {
            if (controller.videoController?.value.isInitialized ?? false) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AspectRatio(
                    aspectRatio: controller.videoController!.value.aspectRatio,
                    child: VideoPlayer(controller.videoController!),
                  ),
                  VideoProgressIndicator(
                    controller.videoController!,
                    allowScrubbing: true,
                  ),
                  IconButton(
                    icon: Icon(
                      controller.videoController!.value.isPlaying
                          ? Icons.pause
                          : Icons.play_arrow,
                    ),
                    onPressed: controller.toggleVideoPlayPause,
                  ),
                ],
              );
            } else {
              return const Center(child: CircularProgressIndicator());
            }
          },
        );

      case MediaType.audio:
        return Obx(() => Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Slider(
                  min: 0,
                  max: controller.duration.value.inSeconds.toDouble(),
                  value: controller.position.value.inSeconds.toDouble(),
                  onChanged: (value) {
                    controller.seekAudio(Duration(seconds: value.toInt()));
                  },
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(controller.position.value.toString().split('.').first),
                    const SizedBox(width: 10),
                    IconButton(
                      iconSize: 50,
                      icon: Icon(
                        controller.isPlaying.value
                            ? Icons.pause
                            : Icons.play_arrow,
                      ),
                      onPressed: controller.toggleAudioPlayPause,
                    ),
                    const SizedBox(width: 10),
                    Text(controller.duration.value.toString().split('.').first),
                  ],
                ),
              ],
            ));
    }
  }

  String _getTitle() {
    switch (controller.mediaType) {
      case MediaType.image:
        return '图片查看';
      case MediaType.video:
        return '视频播放';
      case MediaType.audio:
        return '音频播放';
    }
  }
}
