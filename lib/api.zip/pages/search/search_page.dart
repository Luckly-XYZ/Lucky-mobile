import 'package:flutter/material.dart';

import '../../constants/app_sizes.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _searchController = TextEditingController();
  final List<String> _searchHistory = []; // 搜索历史列表

  @override
  void initState() {
    super.initState();
    _loadSearchHistory();
  }

  // 加载搜索历史
  Future<void> _loadSearchHistory() async {
    // TODO: 从本地存储加载搜索历史
    setState(() {
      _searchHistory.addAll(['Flutter', 'Dart', 'Android', 'iOS']); // 示例数据
    });
  }

  // 保存搜索历史
  Future<void> _saveSearch(String keyword) async {
    if (keyword.trim().isEmpty) return;
    
    setState(() {
      // 移除已存在的相同关键词
      _searchHistory.remove(keyword);
      // 将新关键词添加到列表开头
      _searchHistory.insert(0, keyword);
      // 限制历史记录数量为10条
      if (_searchHistory.length > 10) {
        _searchHistory.removeLast();
      }
    });
    // TODO: 保存到本地存储
  }

  // 清除搜索历史
  void _clearSearchHistory() {
    setState(() {
      _searchHistory.clear();
    });
    // TODO: 清除本地存储的搜索历史
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Expanded(
          child: Container(
            height: 32,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: const Color(0xFFCCCCCC),
                width: 1,
              ),
            ),
            child: TextField(
              controller: _searchController,
              autofocus: true,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                hintText: '搜索',
                hintStyle: TextStyle(color: Colors.grey[400]),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 0,
                ),
                isDense: true,
                prefixIcon: const Icon(
                  Icons.search,
                  color: Color(0xFF999999),
                  size: 18,
                ),
                prefixIconConstraints: const BoxConstraints(
                  minWidth: 40,
                  minHeight: 32,
                ),
              ),
              style: const TextStyle(fontSize: kSize16),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 8),
            ),
            child: const Text('取消'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (_searchHistory.isNotEmpty) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        '搜索历史',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: _clearSearchHistory,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _searchHistory.map((keyword) {
                      return InkWell(
                        onTap: () {
                          _searchController.text = keyword;
                          // TODO: 执行搜索操作
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.grey[100],
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(
                            keyword,
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
